#!/data/data/com.termux/files/usr/bin/sh
set -e

. "$(dirname "$0")/../naming.sh"

OUT=out/images/uefi
ESP=$OUT/esp
EFI=$ESP/EFI/BOOT

mkdir -p "$EFI"

VMLINUX=out/kernel/x86_64/vmlinuz
INITRD=out/initramfs/initrd.img

cp "$VMLINUX" "$EFI/BOOTX64.EFI"
cp "$INITRD" "$EFI/initrd.img"

IMG="$OUT/$(artifact_name uefi x86_64).img"

dd if=/dev/zero of="$IMG" bs=1M count=64
mkfs.vfat "$IMG"

mcopy -i "$IMG" -s "$ESP"/* ::

echo "[UEFI] Image created: $IMG"