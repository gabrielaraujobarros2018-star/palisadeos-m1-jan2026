#!/data/data/com.termux/files/usr/bin/sh
set -e

IMG="$1"
[ -f "$IMG" ] || { echo "Image not found"; exit 1; }

fastboot flash boot "$IMG"
fastboot reboot

echo "[FASTBOOT] Flash complete"