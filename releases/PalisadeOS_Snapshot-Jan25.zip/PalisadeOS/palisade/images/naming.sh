#!/data/data/com.termux/files/usr/bin/sh
set -e

. "$(dirname "$0")/version.mk"

artifact_name() {
    echo "palisadeos-${1}-${2}-${PALISADE_BUILD}"
}