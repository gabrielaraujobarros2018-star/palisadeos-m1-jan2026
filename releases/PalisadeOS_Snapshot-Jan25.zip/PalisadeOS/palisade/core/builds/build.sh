#!/bin/sh
set -e

CC=x86_64-elf-gcc
LD=x86_64-elf-ld
OBJCOPY=x86_64-elf-objcopy

CFLAGS="-ffreestanding -fno-stack-protector -fno-pic -mno-red-zone -O2"
LDFLAGS="-nostdlib"

BUILD=build
EFI=$BUILD/BOOTX64.EFI

mkdir -p $BUILD

$CC $CFLAGS -c kernel/*.c kernel/*.s
$LD $LDFLAGS -T kernel/kernel.ld -o $BUILD/kernel.elf *.o
$OBJCOPY -O elf64-x86-64 $BUILD/kernel.elf $BUILD/kernel.bin

$CC $CFLAGS -c boot/efi_main.c
$LD -T boot/linker.ld -shared -o $EFI efi_main.o $BUILD/kernel.bin

sha256sum $EFI > $EFI.sha256