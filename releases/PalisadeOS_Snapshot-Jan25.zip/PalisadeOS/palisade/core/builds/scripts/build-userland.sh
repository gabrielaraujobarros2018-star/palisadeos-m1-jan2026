#!/bin/sh
set -e
. "$(dirname "$0")/../toolchain/env.sh"

for arch in x86_64 aarch64; do
    make -C userland \
        ARCH="$arch" \
        CC=clang \
        BUILD_ID="$PALISADE_BUILD"
done

echo "[USERLAND] Cross-build complete"