#!/bin/sh
set -e

./builds/scripts/build-images.sh
./builds/scripts/reproducibility-check.sh