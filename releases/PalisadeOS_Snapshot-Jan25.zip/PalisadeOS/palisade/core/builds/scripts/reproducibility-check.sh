#!/bin/sh
set -e

REF="$PALISADE_ROOT/out/reference"
NEW="$PALISADE_ROOT/out/current"

sha256sum "$REF"/* > /tmp/ref.sum
sha256sum "$NEW"/* > /tmp/new.sum

diff -u /tmp/ref.sum /tmp/new.sum && \
echo "[REPRO] PASS" || \
{ echo "[REPRO] FAIL"; exit 1; }