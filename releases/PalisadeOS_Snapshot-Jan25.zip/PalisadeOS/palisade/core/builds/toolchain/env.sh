#!/bin/sh
set -e

ROOT="$(cd "$(dirname "$0")"/../.. && pwd)"
TOOLCHAIN="$ROOT/toolchains"

export PATH="$TOOLCHAIN/bin:$PATH"
export CCACHE_DISABLE=1
export SOURCE_DATE_EPOCH=$(date -d "2026-01-17" +%s)

export PALISADE_BUILD=b01172026
export PALISADE_ROOT="$ROOT"

echo "[TOOLCHAIN] PalisadeOS build $PALISADE_BUILD"