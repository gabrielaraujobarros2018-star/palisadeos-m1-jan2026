#pragma once
void fs_prepare_shutdown(void);