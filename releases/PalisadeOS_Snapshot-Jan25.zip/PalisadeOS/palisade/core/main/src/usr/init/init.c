int init_main(void) {
    for (;;);
    return 0;
}