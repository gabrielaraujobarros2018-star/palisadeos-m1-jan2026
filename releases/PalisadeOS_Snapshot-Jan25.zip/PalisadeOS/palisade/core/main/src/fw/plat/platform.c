int platform_generic(void) {
    return 1;
}