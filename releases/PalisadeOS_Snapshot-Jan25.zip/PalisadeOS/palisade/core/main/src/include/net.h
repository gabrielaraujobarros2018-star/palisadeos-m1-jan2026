#pragma once
int net_is_up(void);