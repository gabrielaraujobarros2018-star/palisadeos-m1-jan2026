#pragma once
int hw_probe(void);