static int touch_events = 0;

void touch_event(void) {
    touch_events++;
}