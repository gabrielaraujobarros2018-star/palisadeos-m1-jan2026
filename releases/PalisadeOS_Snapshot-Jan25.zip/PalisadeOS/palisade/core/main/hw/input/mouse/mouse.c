static int mouse_events = 0;

void mouse_event(void) {
    mouse_events++;
}