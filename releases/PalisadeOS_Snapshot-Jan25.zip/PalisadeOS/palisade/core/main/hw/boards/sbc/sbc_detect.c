int board_is_sbc(void) {
    return 1;
}