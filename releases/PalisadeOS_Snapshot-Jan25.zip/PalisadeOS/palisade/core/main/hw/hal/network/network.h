#pragma once
void network_init(void);