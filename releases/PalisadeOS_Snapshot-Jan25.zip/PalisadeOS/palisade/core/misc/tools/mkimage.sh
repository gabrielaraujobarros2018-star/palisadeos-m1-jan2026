#!/bin/sh
set -e

IMG=palisade.img
SIZE=64M

dd if=/dev/zero of=$IMG bs=1M count=64
parted $IMG mklabel gpt
parted $IMG mkpart ESP fat32 1MiB 100%
parted $IMG set 1 esp on

LOOP=$(losetup --find --show $IMG)
partprobe $LOOP

mkfs.fat -F32 ${LOOP}p1
mkdir -p /mnt/esp
mount ${LOOP}p1 /mnt/esp

mkdir -p /mnt/esp/EFI/BOOT
cp build/BOOTX64.EFI /mnt/esp/EFI/BOOT/

umount /mnt/esp
losetup -d $LOOP