# PalisadeOS Initialization Order (SP1)

This document defines the only valid kernel init sequence.

1. CPU state validation
2. Memory map validation
3. Early allocator (stub in SP1)
4. Platform initialization (no probing)
5. Kernel services (none in SP1)
6. Idle loop

Rules:
- Order must not change per platform
- Skipping a stage is a bug
- Adding a stage requires justification

This document supersedes comments and assumptions.