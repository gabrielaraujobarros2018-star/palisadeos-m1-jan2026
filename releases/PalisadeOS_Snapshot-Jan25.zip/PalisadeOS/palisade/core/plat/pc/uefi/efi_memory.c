#include <efi.h>
#include <efilib.h>

EFI_STATUS efi_exit_boot_services(EFI_HANDLE image) {
    EFI_MEMORY_DESCRIPTOR *map = NULL;
    UINTN map_size = 0, key, desc_size;
    UINT32 version;

    EFI_STATUS st = uefi_call_wrapper(
        BS->GetMemoryMap, 5,
        &map_size, map, &key, &desc_size, &version
    );

    if (st != EFI_BUFFER_TOO_SMALL)
        return st;

    map_size += desc_size * 2;
    map = AllocatePool(map_size);
    if (!map)
        return EFI_OUT_OF_RESOURCES;

    st = uefi_call_wrapper(
        BS->GetMemoryMap, 5,
        &map_size, map, &key, &desc_size, &version
    );
    if (EFI_ERROR(st))
        return st;

    st = uefi_call_wrapper(
        BS->ExitBootServices, 2, image, key
    );

    return st;
}