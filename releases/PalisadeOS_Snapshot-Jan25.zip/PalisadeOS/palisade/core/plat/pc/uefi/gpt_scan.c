#include <efi.h>
#include <efilib.h>

UINTN enumerate_disks(EFI_HANDLE **handles) {
    UINTN count = 0;

    uefi_call_wrapper(
        BS->LocateHandleBuffer, 5,
        ByProtocol,
        &BlockIoProtocol,
        NULL,
        &count,
        handles
    );

    return count;
}