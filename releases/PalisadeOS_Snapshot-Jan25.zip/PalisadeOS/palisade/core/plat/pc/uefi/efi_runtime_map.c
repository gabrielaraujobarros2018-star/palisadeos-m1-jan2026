#include <efi.h>
#include <efilib.h>

int efi_has_runtime_regions(EFI_MEMORY_DESCRIPTOR *map, UINTN count, UINTN sz) {
    for (UINTN i = 0; i < count; i++) {
        EFI_MEMORY_DESCRIPTOR *d =
            (EFI_MEMORY_DESCRIPTOR *)((UINT8 *)map + i * sz);

        if (d->Attribute & EFI_MEMORY_RUNTIME)
            return 1;
    }
    return 0;
}