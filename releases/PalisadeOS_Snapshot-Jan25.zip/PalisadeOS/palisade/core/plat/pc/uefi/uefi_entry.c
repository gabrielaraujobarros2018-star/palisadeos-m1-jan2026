#include "../boot/boot_abi.h"

void uefi_start_kernel(
    void *kernel,
    void *dtb
) {
    struct palisade_boot_info info = {
        .abi_version = PALISADE_BOOT_ABI_VERSION,
        .arch = 0xUEFI,
        .kernel_phys_base = (uint64_t)kernel,
        .dtb = dtb,
        .early_log = 0
    };

    ((palisade_kernel_entry_t)kernel)(&info);
}