#include <efi.h>
#include <efilib.h>

EFI_STATUS open_esp_root(EFI_HANDLE image, EFI_FILE_HANDLE *root) {
    EFI_LOADED_IMAGE *li;
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs;

    EFI_STATUS st = uefi_call_wrapper(
        BS->HandleProtocol, 3,
        image, &LoadedImageProtocol, (VOID **)&li
    );

    if (EFI_ERROR(st))
        return st;

    st = uefi_call_wrapper(
        BS->HandleProtocol, 3,
        li->DeviceHandle,
        &FileSystemProtocol,
        (VOID **)&fs
    );

    return uefi_call_wrapper(fs->OpenVolume, 2, fs, root);
}