#include "../boot/boot_abi.h"

void bios_jump_kernel(void *kernel) {
    struct palisade_boot_info info;
    info.abi_version = PALISADE_BOOT_ABI_VERSION;
    info.arch = 0xX8664;
    info.kernel_phys_base = (uint64_t)kernel;
    info.dtb = 0;
    info.memmap = 0;
    info.memmap_entries = 0;
    info.early_log = 0;

    ((palisade_kernel_entry_t)kernel)(&info);
}