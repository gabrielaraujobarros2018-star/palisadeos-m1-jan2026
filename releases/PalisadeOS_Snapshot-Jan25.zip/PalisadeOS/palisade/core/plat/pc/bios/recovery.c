#include <stdint.h>

static uint32_t failures;

int bios_should_fallback(void) {
    return failures >= 3;
}

void bios_record_failure(void) {
    failures++;
}

void bios_select_stage2(uint64_t *lba) {
    if (bios_should_fallback())
        *lba = 10;
    else
        *lba = 1;
}