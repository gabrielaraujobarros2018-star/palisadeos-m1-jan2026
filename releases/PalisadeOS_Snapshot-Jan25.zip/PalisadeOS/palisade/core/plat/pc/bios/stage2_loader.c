#include <stdint.h>

extern void serial_write(const char *);

#define KERNEL_LOAD_ADDR 0x100000

void pm_main(void) {
    serial_write("stage2: protected mode\n");

    if (!load_kernel()) {
        serial_write("kernel load failed\n");
        for (;;);
    }

    enter_long_mode();
}

int load_kernel(void) {
    /* Disk I/O already abstracted via BIOS stage */
    /* Kernel is preloaded by stage1+stage2 */
    return 1;
}

void enter_long_mode(void) {
    setup_paging();
    enable_long_mode();
}