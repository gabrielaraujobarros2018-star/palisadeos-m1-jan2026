#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MULTIBOOT_MAGIC 0x2BADB002

void mb_load(uint32_t magic, uint32_t info_addr);

/* On success:
 * - kernel entry is jumped to
 * - function never returns
 */

#ifdef __cplusplus
}
#endif