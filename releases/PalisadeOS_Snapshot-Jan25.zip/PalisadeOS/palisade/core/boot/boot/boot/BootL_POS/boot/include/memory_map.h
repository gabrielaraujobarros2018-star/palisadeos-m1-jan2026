#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MEM_TYPE_FREE     1
#define MEM_TYPE_RESERVED 2
#define MEM_TYPE_ACPI     3
#define MEM_TYPE_MMIO     4

struct mem_region {
    uint64_t base;
    uint64_t length;
    uint32_t type;
};

void mem_add(uint64_t base, uint64_t len, uint32_t type);
int  mem_count(void);
struct mem_region *mem_get(int index);

/* The memory map is monotonic and append-only.
 * No region removal or mutation allowed after add.
 */

#ifdef __cplusplus
}
#endif