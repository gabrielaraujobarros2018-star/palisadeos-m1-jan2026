#pragma once
#include <stdint.h>

struct handoff {
    uint64_t kernel_entry;
    uint64_t framebuffer;
    uint32_t width;
    uint32_t height;
    uint32_t pitch;
};