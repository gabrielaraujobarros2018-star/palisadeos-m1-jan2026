#include <stdint.h>
#include <string.h>

struct boot_config {
    char kernel[128];
    char cmdline[256];
};

static struct boot_config cfg;

void config_load(const char *raw) {
    const char *k = strstr(raw, "KERNEL=");
    const char *c = strstr(raw, "CMDLINE=");
    if (k) strncpy(cfg.kernel, k + 7, 127);
    if (c) strncpy(cfg.cmdline, c + 8, 255);
}

const char *config_kernel(void) {
    return cfg.kernel;
}

const char *config_cmdline(void) {
    return cfg.cmdline;
}