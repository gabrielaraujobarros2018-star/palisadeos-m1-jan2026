#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

struct boot_config {
    char kernel[128];
    char cmdline[256];
};

void config_load(const char *raw);
const char *config_kernel(void);
const char *config_cmdline(void);

/* Safety contract:
 * - config_load must be called once
 * - returned pointers remain valid for boot lifetime
 */

#ifdef __cplusplus
}
#endif