#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void video_detect(void);

uint32_t video_width(void);
uint32_t video_height(void);
uint32_t video_bpp(void);

/* Contract:
 * - video_detect must run before querying values
 * - returned values are immutable after detection
 */

#ifdef __cplusplus
}
#endif