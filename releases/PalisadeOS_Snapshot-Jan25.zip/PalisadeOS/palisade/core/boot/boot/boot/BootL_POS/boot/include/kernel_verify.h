#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Verifies kernel integrity.
 * Returns non-zero if verified.
 */
int kernel_verify(void *image, uint64_t size);

/* Verification is deterministic and allocation-free.
 * Caller must halt boot on failure.
 */

#ifdef __cplusplus
}
#endif