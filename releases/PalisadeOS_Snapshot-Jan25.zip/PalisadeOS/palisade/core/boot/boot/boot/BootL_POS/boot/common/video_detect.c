#include <stdint.h>

static uint32_t width;
static uint32_t height;
static uint32_t bpp;

void video_detect(void) {
    width = 1024;
    height = 768;
    bpp = 32;
}

uint32_t video_width(void) { return width; }
uint32_t video_height(void) { return height; }
uint32_t video_bpp(void) { return bpp; }