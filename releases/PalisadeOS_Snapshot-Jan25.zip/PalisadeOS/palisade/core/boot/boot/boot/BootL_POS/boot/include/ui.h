#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Ultra-High-Stability text UI */
void initUHSUI(void);

/* Graphical boot UI */
void initGUI(uint32_t *fb_addr,
             uint32_t width,
             uint32_t height,
             uint32_t pitch);

/* UI must complete before kernel handoff */

#ifdef __cplusplus
}
#endif