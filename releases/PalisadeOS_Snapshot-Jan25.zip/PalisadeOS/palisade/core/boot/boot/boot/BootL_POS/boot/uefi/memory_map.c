#include <efi.h>
#include <efilib.h>

UINTN mmap_size;
EFI_MEMORY_DESCRIPTOR *mmap;
UINTN map_key, desc_size;
UINT32 desc_ver;

EFI_STATUS uefi_memmap(EFI_SYSTEM_TABLE *st) {
    mmap_size = 0;
    uefi_call_wrapper(st->BootServices->GetMemoryMap, 5,
        &mmap_size, mmap, &map_key, &desc_size, &desc_ver);
    mmap_size += 4096;
    uefi_call_wrapper(st->BootServices->AllocatePool, 3,
        EfiLoaderData, mmap_size, (void**)&mmap);
    return uefi_call_wrapper(st->BootServices->GetMemoryMap, 5,
        &mmap_size, mmap, &map_key, &desc_size, &desc_ver);
}