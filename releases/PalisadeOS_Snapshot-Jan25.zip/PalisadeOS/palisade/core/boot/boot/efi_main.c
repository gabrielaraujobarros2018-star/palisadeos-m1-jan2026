#include <efi.h>
#include <efilib.h>

extern void *kernel_start;
extern void *kernel_end;

typedef struct {
    EFI_PHYSICAL_ADDRESS framebuffer_base;
    UINT32 framebuffer_width;
    UINT32 framebuffer_height;
    UINT32 framebuffer_pitch;
    EFI_MEMORY_DESCRIPTOR *memory_map;
    UINTN memory_map_size;
    UINTN memory_map_desc_size;
} boot_info_t;

EFI_STATUS
efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
    InitializeLib(ImageHandle, SystemTable);

    EFI_STATUS status;
    EFI_MEMORY_DESCRIPTOR *memory_map = NULL;
    UINTN map_size = 0, map_key, desc_size;
    UINT32 desc_version;

    status = uefi_call_wrapper(
        SystemTable->BootServices->GetMemoryMap,
        5,
        &map_size,
        memory_map,
        &map_key,
        &desc_size,
        &desc_version
    );

    map_size += 2 * desc_size;
    status = uefi_call_wrapper(
        SystemTable->BootServices->AllocatePool,
        3,
        EfiLoaderData,
        map_size,
        (void **)&memory_map
    );

    status = uefi_call_wrapper(
        SystemTable->BootServices->GetMemoryMap,
        5,
        &map_size,
        memory_map,
        &map_key,
        &desc_size,
        &desc_version
    );

    boot_info_t boot_info;
    boot_info.memory_map = memory_map;
    boot_info.memory_map_size = map_size;
    boot_info.memory_map_desc_size = desc_size;

    uefi_call_wrapper(SystemTable->BootServices->ExitBootServices, 2, ImageHandle, map_key);

    void (*kernel_entry)(boot_info_t *) = (void (*)(boot_info_t *))&kernel_start;
    kernel_entry(&boot_info);

    while (1);
    return EFI_SUCCESS;
}