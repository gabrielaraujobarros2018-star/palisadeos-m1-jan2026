#include "../include/boot.h"

static int secureboot_enforced = 0;

void secureboot_detect(int firmware_flag) {
    secureboot_enforced = firmware_flag ? 1 : 0;

    if (secureboot_enforced) {
        boot_log("UEFI SECURE BOOT ENABLED");
    } else {
        boot_log("UEFI SECURE BOOT BYPASSED");
    }
}

int secureboot_active(void) {
    return secureboot_enforced;
}