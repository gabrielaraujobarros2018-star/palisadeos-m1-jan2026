#include <stdint.h>
#include "../include/boot.h"

extern void kernel_main(uintptr_t);

void uefi_entry(void *efi_handle, void *system_table) {
    (void)efi_handle;
    (void)system_table;

    struct boot_context ctx;
    ctx.target = BOOT_X86_64_UEFI;
    ctx.stage = BOOT_STAGE_STUB;
    ctx.timestamp = 0;
    ctx.handoff_data = system_table;

    boot_log("UEFI ENTRY");
    boot_set_stage(BOOT_STAGE_STUB);
    boot_verify_context(&ctx);

    kernel_main((uintptr_t)&ctx);

    for (;;) { __asm__ volatile("hlt"); }
}