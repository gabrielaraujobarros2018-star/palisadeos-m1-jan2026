#include <stdint.h>
#include "../include/boot.h"

int uefi_handoff_validate(void *st) {
    if (!st) {
        boot_log("UEFI HANDOFF FAIL");
        return 0;
    }

    boot_log("UEFI HANDOFF OK");
    return 1;
}

void uefi_prepare_handoff(void *st) {
    if (!uefi_handoff_validate(st)) {
        for (;;) {}
    }

    boot_log("UEFI HANDOFF PREPARED");
}