#include <stdint.h>

int ram_validate(uint64_t base, uint64_t size) {
    if (base < 0x40000000) return -1;
    if (size < (256 * 1024 * 1024)) return -2;
    if ((base & 0xFFF) != 0) return -3;
    return 0;
}