#ifndef NEOKERN_SERIAL_H
#define NEOKERN_SERIAL_H

#include "types.h"

void serial_init(void);
void serial_write(const char *s);
void serial_write_hex(u64 value);

#endif