#pragma once

/* NeoKern fundamental types — no libc */

typedef unsigned char      u8;
typedef unsigned short     u16;
typedef unsigned int       u32;
typedef unsigned long long u64;

typedef signed char        s8;
typedef signed short       s16;
typedef signed int         s32;
typedef signed long long   s64;

typedef u64 size_t;
typedef s64 ssize_t;

#define NULL ((void*)0)

#define ALIGN_UP(x, a)   (((x) + ((a) - 1)) & ~((a) - 1))
#define ALIGN_DOWN(x, a) ((x) & ~((a) - 1))

_Static_assert(sizeof(u8)  == 1, "u8 size mismatch");
_Static_assert(sizeof(u16) == 2, "u16 size mismatch");
_Static_assert(sizeof(u32) == 4, "u32 size mismatch");
_Static_assert(sizeof(u64) == 8, "u64 size mismatch");