#include <stdint.h>

extern uint8_t __bss_start;
extern uint8_t __bss_end;
extern uint8_t __data_start;
extern uint8_t __data_end;

static void bss_zero(void) {
    uint8_t *p = &__bss_start;
    while (p < &__bss_end) {
        *p++ = 0;
    }
}

static int data_validate(void) {
    uint8_t *p = &__data_start;
    while (p < &__data_end) {
        if ((uintptr_t)p == 0) {
            return -1; // impossible unless linker broke
        }
        p++;
    }
    return 0;
}

void runtime_init(void) {
    bss_zero();

    if (data_validate() != 0) {
        while (1) {
            __asm__ volatile ("cli; hlt");
        }
    }
}