#pragma once
#include <stdint.h>

enum protect_event {
    PROTECT_BATTERY = 1,
    PROTECT_KERNEL_FAULT,
    PROTECT_GRAPHICS,
    PROTECT_FILESYSTEM,
    PROTECT_MEMORY,
    PROTECT_THERMAL,
    PROTECT_SECURITY
};

void protect_init(void);
void protect_trigger(enum protect_event event);
void protect_lockdown(void);

/*
 * All protections:
 * - Kernel-only
 * - Non-bypassable by userspace
 * - Prefer shutdown over corruption
 */