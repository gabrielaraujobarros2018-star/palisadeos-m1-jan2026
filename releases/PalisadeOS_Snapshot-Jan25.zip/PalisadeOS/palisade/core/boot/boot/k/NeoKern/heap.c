#include <stdint.h>

#define HEAP_SIZE 65536

static uint8_t heap[HEAP_SIZE];
static uintptr_t heap_top = 0;

void *heap_alloc(uint64_t size) {
    if (size == 0) {
        return (void *)0;
    }

    if (heap_top + size > HEAP_SIZE) {
        return (void *)0;
    }

    void *ptr = &heap[heap_top];
    heap_top += size;

    // Align to 16 bytes
    heap_top = (heap_top + 15) & ~15;

    return ptr;
}

uint64_t heap_used(void) {
    return heap_top;
}