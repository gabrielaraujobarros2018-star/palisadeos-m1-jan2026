/*
 * Multiboot2 header for NeoKern
 * QEMU -kernel compatible
 */

#include <stdint.h>

/* Multiboot2 constants */
#define MULTIBOOT2_MAGIC        0xE85250D6u
#define MULTIBOOT2_ARCH_X86     0u
#define MULTIBOOT2_HEADER_ALIGN 8

struct multiboot2_header {
    uint32_t magic;
    uint32_t architecture;
    uint32_t header_length;
    uint32_t checksum;

    struct {
        uint16_t type;
        uint16_t flags;
        uint32_t size;
    } end_tag;
};

__attribute__((used))
__attribute__((section(".text")))
__attribute__((aligned(MULTIBOOT2_HEADER_ALIGN)))
static const struct multiboot2_header multiboot2_header = {
    .magic = MULTIBOOT2_MAGIC,
    .architecture = MULTIBOOT2_ARCH_X86,
    .header_length = (uint32_t)sizeof(struct multiboot2_header),
    .checksum = (uint32_t)(
        0u - (MULTIBOOT2_MAGIC +
              MULTIBOOT2_ARCH_X86 +
              (uint32_t)sizeof(struct multiboot2_header))
    ),
    .end_tag = {
        .type = 0,
        .flags = 0,
        .size = 8
    }
};