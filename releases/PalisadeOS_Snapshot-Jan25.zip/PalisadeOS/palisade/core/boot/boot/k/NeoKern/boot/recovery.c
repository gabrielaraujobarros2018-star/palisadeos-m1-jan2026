#include <stdint.h>

static int recovery_active = 0;

void recovery_enter(void) {
    recovery_active = 1;
}

int recovery_is_active(void) {
    return recovery_active;
}

void recovery_restrict_system(void) {
    if (!recovery_active)
        return;

    /* Recovery mode limitations:
     * - No user processes
     * - No network
     * - No updates auto-applied
     */
}

void recovery_exit(void) {
    recovery_active = 0;
}

/*
 * Recovery is not a shell.
 * It is a constrained execution environment.
 */