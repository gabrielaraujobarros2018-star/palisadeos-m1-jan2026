#include <stdint.h>

int lipo_detected(void) {
    return 0;
}