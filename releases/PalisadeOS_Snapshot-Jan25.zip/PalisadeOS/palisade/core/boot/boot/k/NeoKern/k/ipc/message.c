#include <stdint.h>

typedef struct {
    uint32_t sender;
    uint32_t value;
} ipc_message_t;

static ipc_message_t last_msg;

void ipc_send(uint32_t from, uint32_t value) {
    last_msg.sender = from;
    last_msg.value = value;
}