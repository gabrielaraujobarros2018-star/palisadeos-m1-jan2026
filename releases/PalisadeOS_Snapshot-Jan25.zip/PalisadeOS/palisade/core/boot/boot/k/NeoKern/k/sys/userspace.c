#include <stdint.h>

int userspace_enter(void) {
    return -1;
}