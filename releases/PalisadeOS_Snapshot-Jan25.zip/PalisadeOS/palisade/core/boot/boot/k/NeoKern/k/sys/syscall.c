#include <stdint.h>

uint64_t sys_null(void) {
    return 0;
}