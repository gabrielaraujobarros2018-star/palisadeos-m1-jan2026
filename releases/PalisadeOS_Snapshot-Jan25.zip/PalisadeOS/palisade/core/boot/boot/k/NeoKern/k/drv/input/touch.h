#ifndef KERNEL_DRIVERS_INPUT_TOUCH_H
#define KERNEL_DRIVERS_INPUT_TOUCH_H

int touch_supported(void);

#endif