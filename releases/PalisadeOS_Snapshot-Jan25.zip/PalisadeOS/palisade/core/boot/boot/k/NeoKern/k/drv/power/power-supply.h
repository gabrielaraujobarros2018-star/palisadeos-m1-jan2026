#ifndef KERNEL_DRIVERS_POWER_SUPPLY_H
#define KERNEL_DRIVERS_POWER_SUPPLY_H

int power_online(void);

#endif