#include "kernel.h"

#define COM1_PORT 0x3F8

static inline void outb(u16 port, u8 val) {
    __asm__ volatile ("outb %0, %1" :: "a"(val), "Nd"(port));
}

static inline u8 inb(u16 port) {
    u8 ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

void serial_init(void) {
    outb(COM1_PORT + 1, 0x00);    /* Disable interrupts */
    outb(COM1_PORT + 3, 0x80);    /* Enable DLAB */
    outb(COM1_PORT + 0, 0x03);    /* Baud divisor low */
    outb(COM1_PORT + 1, 0x00);    /* Baud divisor high */
    outb(COM1_PORT + 3, 0x03);    /* 8 bits, no parity */
    outb(COM1_PORT + 2, 0xC7);    /* FIFO */
    outb(COM1_PORT + 4, 0x0B);    /* IRQs enabled */
}

void serial_write(const char *s) {
    while (*s) {
        while (!(inb(COM1_PORT + 5) & 0x20)) {}
        outb(COM1_PORT, *s++);
    }
}