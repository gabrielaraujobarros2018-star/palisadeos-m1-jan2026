#include <stdint.h>

struct gdt_entry {
    uint16_t limit;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  gran;
    uint8_t  base_high;
} __attribute__((packed));

static struct gdt_entry gdt[3];

void gdt64_init(void) {
    gdt[0] = (struct gdt_entry){0};
}