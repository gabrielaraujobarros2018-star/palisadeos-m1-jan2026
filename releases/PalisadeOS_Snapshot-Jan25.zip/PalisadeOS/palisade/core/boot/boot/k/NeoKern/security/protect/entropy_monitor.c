/* NeoKern/security/protect/entropy_monitor.c */
#include <stdint.h>

static uint32_t entropy_level = 0;
static uint32_t entropy_minimum = 128;

void entropy_add(uint32_t bits) {
    entropy_level += bits;
}

int entropy_ready(void) {
    return entropy_level >= entropy_minimum;
}

void entropy_consume(uint32_t bits) {
    if (entropy_level >= bits)
        entropy_level -= bits;
}

void entropy_reset(void) {
    entropy_level = 0;
}

/*
 * Prevents:
 * - Weak keys
 * - Predictable randomness
 */