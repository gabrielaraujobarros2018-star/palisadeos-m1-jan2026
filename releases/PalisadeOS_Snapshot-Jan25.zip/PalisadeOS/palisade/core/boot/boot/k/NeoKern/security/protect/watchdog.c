/* NeoKern/security/protect/watchdog.c */
#include <stdint.h>

static uint64_t watchdog_last_tick = 0;
static uint64_t watchdog_timeout = 5000;

void watchdog_init(uint64_t now) {
    watchdog_last_tick = now;
}

void watchdog_pet(uint64_t now) {
    watchdog_last_tick = now;
}

void watchdog_check(uint64_t now) {
    if ((now - watchdog_last_tick) > watchdog_timeout) {
        /* Kernel stalled */
        for (;;) {
#if defined(__x86_64__)
            __asm__ volatile ("hlt");
#elif defined(__aarch64__)
            __asm__ volatile ("wfi");
#endif
        }
    }
}

void watchdog_set_timeout(uint64_t ticks) {
    watchdog_timeout = ticks;
}

/*
 * Prevents silent deadlocks.
 * Forces visible failure.
 */