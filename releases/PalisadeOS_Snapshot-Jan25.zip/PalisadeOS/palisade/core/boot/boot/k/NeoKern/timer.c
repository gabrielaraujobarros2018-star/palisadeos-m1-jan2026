#include <stdint.h>

static int timer_ready = 0;

void timer_init(void) {
    // Stub: no hardware touched
    timer_ready = 1;
}

int timer_is_ready(void) {
    return timer_ready;
}

uint64_t timer_ticks(void) {
    // No real time source yet
    return 0;
}