#ifndef KERNEL_DRIVERS_STORAGE_ATA_H
#define KERNEL_DRIVERS_STORAGE_ATA_H

int ata_detect(void);

#endif