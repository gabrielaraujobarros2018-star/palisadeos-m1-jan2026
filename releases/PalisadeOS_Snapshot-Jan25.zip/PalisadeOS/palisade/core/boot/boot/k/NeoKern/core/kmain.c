#include <stdint.h>
#include "kernel.h"

void kernel_main(void) {
    kernel_log("NeoKern kernel_main entered");

    for (;;) {
        cpu_idle();
    }
}

void cpu_idle(void) {
#if defined(__x86_64__)
    asm volatile ("hlt");
#elif defined(__aarch64__)
    asm volatile ("wfe");
#else
    for (;;) {}
#endif
}