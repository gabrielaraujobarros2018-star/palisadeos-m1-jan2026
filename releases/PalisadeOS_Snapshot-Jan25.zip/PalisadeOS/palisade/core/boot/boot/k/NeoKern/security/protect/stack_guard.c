/* NeoKern/security/protect/stack_guard.c */
#include <stdint.h>

#define STACK_CANARY 0xBADC0FFEE0DDF00DULL

static uint64_t kernel_canary = STACK_CANARY;

void stack_guard_init(void) {
    kernel_canary = STACK_CANARY;
}

void stack_guard_check(uint64_t observed) {
    if (observed != kernel_canary) {
        /* Stack corruption detected */
        for (;;) {
#if defined(__x86_64__)
            __asm__ volatile ("cli; hlt");
#elif defined(__aarch64__)
            __asm__ volatile ("msr daifset, #0xf; wfi");
#endif
        }
    }
}

uint64_t stack_guard_value(void) {
    return kernel_canary;
}

/*
 * No recovery.
 * Stack corruption = compromised kernel.
 */