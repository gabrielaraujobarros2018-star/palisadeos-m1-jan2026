#include <stdint.h>
#include "kernel.h"
#include "config.h"
#include "types.h"

void arch_x86_64_init(void) {
    kernel_log("ARCH INIT x86_64");

    __asm__ volatile("cli");

    uint64_t cr0;
    __asm__ volatile("mov %%cr0, %0" : "=r"(cr0));

    if (!(cr0 & 1)) {
        panic(0xC10BAD01);
    }

    __asm__ volatile("sti");
}
