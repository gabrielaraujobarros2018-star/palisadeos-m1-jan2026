#pragma once
void arch_init(void);
void arch_enable_mmu(void);