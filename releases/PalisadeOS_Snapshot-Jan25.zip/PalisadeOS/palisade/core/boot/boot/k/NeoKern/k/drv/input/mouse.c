#include <stdint.h>

void mouse_init(void) {
    /* PS/2 init stub */
}