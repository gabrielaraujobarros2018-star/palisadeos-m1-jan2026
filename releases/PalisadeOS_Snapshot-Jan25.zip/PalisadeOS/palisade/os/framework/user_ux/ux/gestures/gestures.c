static int gestures = 0;

void gesture_event(void) {
    gestures++;
}