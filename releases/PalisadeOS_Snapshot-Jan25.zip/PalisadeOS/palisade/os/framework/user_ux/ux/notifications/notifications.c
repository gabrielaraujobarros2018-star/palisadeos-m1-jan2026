static int notifications = 0;

void notify(void) {
    notifications++;
}