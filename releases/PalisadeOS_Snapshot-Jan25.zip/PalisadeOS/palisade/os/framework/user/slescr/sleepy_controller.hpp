#pragma once

namespace palisade::features::sleepy {

void armSleepTimer();
void cancelSleep();

}