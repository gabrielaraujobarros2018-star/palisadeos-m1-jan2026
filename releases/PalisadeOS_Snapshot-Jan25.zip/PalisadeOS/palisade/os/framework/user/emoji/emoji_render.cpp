namespace palisade::features::emoji {

void renderEmoji(uint32_t codepoint) {
    // Glyph resolved via OS font stack
}

bool supportsColorEmoji() {
    return true;
}

}