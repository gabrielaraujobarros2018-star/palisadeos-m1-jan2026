#ifndef _PALISADE_KERNEL_H
#define _PALISADE_KERNEL_H

void kmain(void);
void panic(const char* msg);

#endif