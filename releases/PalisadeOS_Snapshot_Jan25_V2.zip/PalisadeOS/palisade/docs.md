# PalisadeOS b01172026 Documentation

## 1. Boot Flow Overview

PalisadeOS follows a **firmware-to-kernel direct boot model** with minimal intermediaries. The design goal is deterministic control over execution from power-on to userland, across both desktop-class and mobile-class hardware.

### 1.1 Firmware → Kernel

#### x86_64 (UEFI)

1. System firmware initializes CPU, memory controller, and essential devices.
2. UEFI firmware loads `BOOTX64.EFI` from the EFI System Partition (ESP).
3. The EFI binary is a Linux kernel image built with the EFI stub enabled.
4. UEFI passes control directly to the kernel entry point along with memory maps, ACPI tables, and command line parameters.

No secondary bootloader (GRUB, systemd-boot) is involved.

#### ARM64 (Android A/B)

1. SoC ROM executes vendor boot ROM code.
2. Vendor bootloader selects the active A/B slot.
3. `boot.img` is loaded into memory (kernel + initramfs).
4. Control transfers directly to the Linux kernel entry point.

Verified Boot is currently **bypassed**, not integrated.

### 1.2 Kernel → Init

1. Kernel performs early architecture setup.
2. Device tree (ARM64) or ACPI (x86_64) is parsed.
3. Core subsystems initialize: memory, scheduler, VFS, device model.
4. `initramfs` is unpacked.
5. Kernel executes `/init` as PID 1.

The kernel is configured to fail fast on unrecoverable errors to keep boot diagnostics explicit.

---

## 2. Kernel Patching and Build Process

### 2.1 Base Kernel Strategy

PalisadeOS uses an upstream Linux kernel as its base. Patches are:

* Minimal
* Purpose-specific
* Maintained as a linear queue

No out-of-tree rewrites are performed.

### 2.2 Patch Queue Discipline

* Each patch has a single responsibility
* Patches apply cleanly on top of the frozen base version
* No patch modifies generated files

Patches are applied before configuration and build.

### 2.3 Kernel Build (Per Architecture)

#### Common Settings

* Compiler: LLVM/Clang
* Linker: LLD
* Deterministic timestamps
* Build ID: `b01172026`

#### x86_64

* Output: `bzImage`
* EFI stub enabled
* Framebuffer and early console enabled

#### ARM64

* Output: `Image`
* Android compatibility enabled
* Initramfs support enabled

All builds are performed out-of-tree (`O=out/kernel/<arch>`).

---

## 3. Cross-Build Environment

### 3.1 Supported Hosts

* Linux (desktop)
* Android (Termux)

The build system does not depend on distribution-specific tooling.

### 3.2 Toolchain Pinning

* LLVM: pinned version
* GCC: pinned version (fallback or cross tools)
* Binutils: pinned

Toolchain paths are explicitly controlled via environment scripts.

### 3.3 Reproducibility Guarantees

* `SOURCE_DATE_EPOCH` is fixed
* Build metadata is deterministic
* CI verifies binary equivalence across runs

Any drift is treated as a build failure.

---

## 4. b01172026 Release Notes

### 4.1 Build Identification

* Version: b01172026
* Date-based snapshot
* Foundation build

### 4.2 Scope of This Build

* Full repository structural completion
* Defined and locked boot flow for x86_64 and ARM64
* Toolchain and CI infrastructure established
* Image and deployment format finalized
* Kernel and userland still under active development

### 4.3 Non-Goals

* End-user usability
* Security hardening
* Feature completeness

This build exists to **solidify the foundation**, not to ship a product.

### 4.4 Forward Direction

Next builds will focus on:

* Kernel feature completion
* Hardware driver bring-up
* Init and userland execution stability
* First successful boots on real hardware

---

End of b01172026 documentation.