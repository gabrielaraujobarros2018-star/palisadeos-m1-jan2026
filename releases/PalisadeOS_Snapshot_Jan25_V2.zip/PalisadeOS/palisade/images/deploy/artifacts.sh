#!/data/data/com.termux/files/usr/bin/sh
set -e

ls -lh out/images/uefi
ls -lh out/images/android