#!/data/data/com.termux/files/usr/bin/sh
set -e

. "$(dirname "$0")/../naming.sh"

OUT=out/images/android
mkdir -p "$OUT"

VMLINUX=out/kernel/arm64/Image
INITRD=out/initramfs/initrd.img

IMG="$OUT/$(artifact_name android arm64).boot.img"

mkbootimg \
  --kernel "$VMLINUX" \
  --ramdisk "$INITRD" \
  --pagesize 4096 \
  --cmdline "androidboot.hardware=palisade" \
  --output "$IMG"

echo "[ANDROID] boot.img created: $IMG"