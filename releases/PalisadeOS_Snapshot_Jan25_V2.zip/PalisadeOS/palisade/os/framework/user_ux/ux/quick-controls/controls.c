static int toggles = 0;

void control_toggle(void) {
    toggles++;
}