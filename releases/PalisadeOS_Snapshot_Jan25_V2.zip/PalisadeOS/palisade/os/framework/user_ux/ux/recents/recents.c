static int recent_apps = 0;

void recent_add(void) {
    recent_apps++;
}