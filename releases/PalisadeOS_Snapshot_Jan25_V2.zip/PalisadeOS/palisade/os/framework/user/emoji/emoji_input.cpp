namespace palisade::features::emoji {

void onEmojiPickerOpened() {
    preloadCommonEmoji();
}

void preloadCommonEmoji() {
    // Improves UI responsiveness
}

}