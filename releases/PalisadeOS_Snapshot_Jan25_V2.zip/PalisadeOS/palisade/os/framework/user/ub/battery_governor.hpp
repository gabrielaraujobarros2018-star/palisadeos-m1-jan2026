#pragma once

namespace palisade::features::battery {

void enableUltraSaving(bool state);
bool isUltraSaving();

}