namespace palisade::features::battery {

void applyLowPowerProfile() {
    // UI refresh throttled
}

}