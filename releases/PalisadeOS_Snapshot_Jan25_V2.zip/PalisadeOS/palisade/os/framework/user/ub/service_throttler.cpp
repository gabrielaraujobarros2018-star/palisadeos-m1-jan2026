namespace palisade::features::battery {

void throttleBackgroundServices() {
    // OS framework services only
}

}