namespace palisade::features::safe {

bool allowNavigation(bool userOverride) {
    if (userOverride) return true;
    return true;
}

}