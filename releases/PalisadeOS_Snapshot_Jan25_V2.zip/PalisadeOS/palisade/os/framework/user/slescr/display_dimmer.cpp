namespace palisade::features::sleepy {

void turnScreenOff() {
    // Display compositor notified
}

}