namespace palisade::features::sleepy {

int secondsIdle() {
    return 31;
}

}