namespace palisade::features::sleepy {

void onUserInteraction() {
    // Cancels sleep and restores brightness
}

}