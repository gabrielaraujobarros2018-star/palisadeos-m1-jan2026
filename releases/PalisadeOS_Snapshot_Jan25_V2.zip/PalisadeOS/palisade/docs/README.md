# PalisadeOS

PalisadeOS is a **minimal, experimental operating system** built as a real-world learning and engineering project focused on understanding how systems boot, initialize hardware, and evolve from firmware-level code into a functional OS environment.

This project is **not theoretical** — every build reflects actual constraints, tradeoffs, and mistakes encountered during low-level development.

---

## Reality Check

- PalisadeOS is **early-stage** and **not production-ready**
- Booting on real hardware is **still in progress**
- Many features are **stubbed, incomplete, or intentionally absent**
- Stability, compatibility, and security are **not guaranteed**
- The project favors **clarity and control** over speed or feature count

This OS exists to **learn how operating systems truly work**, not to compete with Linux, BSD, or Android.

---

## Core Goals

- Understand the **real boot process** (firmware → bootloader → kernel)
- Build a **clean and understandable OS structure**
- Keep the system **small, inspectable, and hackable**
- Avoid unnecessary abstractions and bloat
- Learn from real failures, not tutorials alone

---

## Versioning System

PalisadeOS uses a **date-based build system**:
.. bMMDDYYYY
Copy code

Example:
1.0.2 b01152026

- Builds before `1.2` are often **daily experimental builds**
- Version numbers reflect **real progress**, not marketing milestones

---

## Current State (Reality-Based)

- Latest builds are approximately **4 MB**
- No full GUI yet
- Hardware support is minimal and selective
- Kernel services are under active development
- Runtime environment is skeletal
- Debugging is frequent and expected

---

## What PalisadeOS Is NOT

- Not a Linux distro
- Not Android-based
- Not a ROM replacement (yet)
- Not optimized for end users
- Not designed for long-term stability

---

## What PalisadeOS IS

- A **learning-first OS**
- A **firmware-to-kernel exploration**
- A **controlled environment** for low-level experiments
- A project shaped by **real constraints and burnout-aware development**

---

## Development Philosophy

- Small builds over massive rewrites
- Short, focused development bursts
- Features only exist when they are understood
- If something breaks, it’s a lesson — not a failure
- Abandoning paths is acceptable when they stop teaching

---

## Licensing & Assets

- Source code license: *project-defined*
- Fonts and visual assets may carry **explicit copyright**
- Check individual asset folders for licensing details

---

## Disclaimer

PalisadeOS can crash, fail to boot, corrupt data, or do nothing at all.

That’s part of the process.

---

## Status

**Active experimental development**

Progress is measured in **understanding gained**, not features shipped.

---

## Platform Intent & Legal Notice (For Developers)

### Target Devices

PalisadeOS is **designed to be flashed** on:

- **Android smartphones** (bootloader / firmware-level experimentation)
- **Desktop and laptop PCs** (traditional firmware environments)

This is a deliberate cross-platform effort focused on understanding **real hardware boot paths**, storage layouts, and OS handoff mechanics across mobile and desktop ecosystems.

---

### Project Nature Clarification

- PalisadeOS is **not a prototype**
- PalisadeOS is **not a casual hobby project**
- PalisadeOS is a **serious system-level engineering effort**

While experimental in nature, the project is built with **real deployment scenarios in mind**, including flashing, boot validation, and hardware interaction.

“Experimental” does not mean disposable.

---

### Assets & Copyright

- **Copyright may apply to assets**
- Fonts, visual elements, and other non-code resources may be:
  - Proprietary
  - Restricted
  - Individually licensed

Developers must **check asset directories** before reuse, redistribution, or modification.

Source code and assets are **not automatically under the same license**.

---

### Developer Responsibility

By contributing or experimenting with PalisadeOS, developers acknowledge:

- Flashing firmware or OS images carries real risk
- Devices can be rendered unusable if handled incorrectly
- Assets may have legal constraints separate from code

This project assumes contributors understand **low-level system risks** and **respect intellectual property boundaries**.

---

## Daily Use & Custom ROM Statement

PalisadeOS is **made** for daily use and **can** function as a **custom ROM**.

This is not a showcase build or a proof-of-concept image. The system is developed with the expectation that it will be **installed, booted, used, and lived on** — not just tested and discarded.

### Intended Usage Model

- Designed to operate as a **primary operating system**
- Built with **long-session stability** as a requirement, not an afterthought
- Expected to handle repeated boots, real storage, and user persistence
- Developed to survive updates, reboots, and configuration changes

### Custom ROM Positioning

- PalisadeOS is not layered on top of Android
- It replaces the operating system stack at the boot level
- The ROM model assumes:
  - Flashing via standard or custom bootloader paths
  - Real partitions, not emulation
  - Persistent user data and runtime state

### Reality-Aligned Expectations

Daily use does **not** imply feature parity with Android or desktop OSes.

It means:
- The OS is built to be **relied upon**
- Failures are treated as **system bugs**, not acceptable behavior
- Regressions are taken seriously
- The system is expected to improve toward reliability, not remain unstable

### User Awareness

Users choosing PalisadeOS as a daily system accept:
- Limited app ecosystems in early stages
- Reduced hardware compatibility
- Active development impacts

What they gain is **control**, **transparency**, and an OS that evolves with real usage, not theoretical goals.

---

# LICENSE — Assets Notice

## Copyrighted Assets

All **assets** included in the PalisadeOS project are **copyrighted**.

This includes, but is not limited to:

- Visual elements (UI graphics, icons, wallpapers, illustrations)
- Fonts (custom, modified, or embedded typefaces)
- Audio files (sounds, tones, boot audio, notifications)

---

## Rights Reserved

Unless explicitly stated otherwise in a specific asset directory:

- **All rights are reserved**
- Assets may **not** be copied, redistributed, modified, sublicensed, or reused
- Commercial and non-commercial reuse is **not permitted**
- Derivative works using these assets are **not allowed**

---

## Scope Clarification

- This notice applies **only to assets**
- Source code licensing is **separate** and may differ
- Code and assets are **not automatically covered by the same license**

Each asset folder may contain additional notices or clarifications.  
In the absence of such notices, this LICENSE file takes precedence.

---

## Contributor Awareness

By contributing assets to PalisadeOS, contributors acknowledge that:

- Submitted assets are either original or legally owned
- They grant the project the right to include them under this copyright notice
- They understand assets will be treated as protected material

---

## Enforcement

Unauthorized use of PalisadeOS assets may result in:

- Takedown requests
- Removal from downstream projects
- Legal enforcement where applicable

---

## Summary

- Assets are **protected**
- Permission is **required** for any form of reuse
- Assume **copyright applies** unless explicitly stated otherwise