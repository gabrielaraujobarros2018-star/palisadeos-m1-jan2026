#include <stdint.h>

const char *easteregg_cow(void) {
    return "moo";
}

int cow_is_happy(void) {
    return 1;
}

void cow_init(void) {
}