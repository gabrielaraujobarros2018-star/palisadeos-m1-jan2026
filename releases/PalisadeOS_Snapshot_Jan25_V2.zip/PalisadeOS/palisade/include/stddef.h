#ifndef _STDDEF_H
#define _STDDEF_H

#define NULL ((void*)0)
typedef unsigned long size_t;

#endif