#include "mmio.h"

#define PL011_BASE 0x09000000UL
#define UART_DR   0x00
#define UART_FR   0x18
#define FR_TXFF   (1 << 5)

void uart_putc(char c) {
    while (mmio_read32(PL011_BASE + UART_FR) & FR_TXFF);
    mmio_write32(PL011_BASE + UART_DR, c);
}

void uart_write(const char *s) {
    if (!s) return;
    while (*s) {
        if (*s == '\n')
            uart_putc('\r');
        uart_putc(*s++);
    }
}