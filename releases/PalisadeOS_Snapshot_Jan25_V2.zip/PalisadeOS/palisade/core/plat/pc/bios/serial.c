#include <stdint.h>

#define COM1 0x3F8

static inline void outb(uint16_t p, uint8_t v) {
    asm volatile("outb %0,%1"::"a"(v),"Nd"(p));
}

void serial_init(void) {
    outb(COM1 + 1, 0);
    outb(COM1 + 3, 0x80);
    outb(COM1 + 0, 3);
    outb(COM1 + 1, 0);
    outb(COM1 + 3, 3);
    outb(COM1 + 2, 0xC7);
    outb(COM1 + 4, 0x0B);
}

void serial_write(const char *s) {
    while (*s)
        outb(COM1, *s++);
}