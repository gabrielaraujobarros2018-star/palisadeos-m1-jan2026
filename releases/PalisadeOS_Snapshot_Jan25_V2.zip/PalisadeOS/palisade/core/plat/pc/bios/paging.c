#include <stdint.h>

#define PML4_ADDR 0x200000
#define PDP_ADDR  0x201000
#define PD_ADDR   0x202000

void setup_paging(void) {
    uint64_t *pml4 = (uint64_t *)PML4_ADDR;
    uint64_t *pdp  = (uint64_t *)PDP_ADDR;
    uint64_t *pd   = (uint64_t *)PD_ADDR;

    pml4[0] = PDP_ADDR | 3;
    pdp[0]  = PD_ADDR | 3;

    for (int i = 0; i < 512; i++)
        pd[i] = (i * 0x200000ULL) | 0x83;
}

void enable_long_mode(void) {
    uint64_t efer;
    asm volatile("rdmsr" : "=A"(efer) : "c"(0xC0000080));
    efer |= 1 << 8;
    asm volatile("wrmsr" :: "c"(0xC0000080), "A"(efer));

    asm volatile("mov %0, %%cr3" :: "r"(PML4_ADDR));
    asm volatile("mov %cr0, %rax\n or $0x80000001, %rax\n mov %rax, %cr0");
}