#include <efi.h>
#include <efilib.h>

CHAR16 *efi_get_cmdline(EFI_HANDLE image) {
    EFI_LOADED_IMAGE *li;
    EFI_STATUS st = uefi_call_wrapper(
        BS->HandleProtocol, 3,
        image, &LoadedImageProtocol, (VOID **)&li
    );

    if (EFI_ERROR(st) || !li->LoadOptions)
        return NULL;

    return (CHAR16 *)li->LoadOptions;
}