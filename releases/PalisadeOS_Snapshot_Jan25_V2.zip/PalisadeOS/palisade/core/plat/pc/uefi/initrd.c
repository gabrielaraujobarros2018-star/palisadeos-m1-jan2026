#include <efi.h>
#include <efilib.h>

EFI_STATUS load_initrd(
    EFI_FILE_HANDLE root,
    VOID **initrd,
    UINTN *size
) {
    return load_kernel(
        NULL,
        root,
        L"\\palisade\\initrd.img",
        initrd,
        size
    );
}