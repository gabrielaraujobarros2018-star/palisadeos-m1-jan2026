#include <efi.h>
#include <efilib.h>

static EFI_SYSTEM_TABLE *ST;
static EFI_BOOT_SERVICES *BS;
static EFI_RUNTIME_SERVICES *RT;

EFI_STATUS efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
    ST = SystemTable;
    BS = SystemTable->BootServices;
    RT = SystemTable->RuntimeServices;

    InitializeLib(ImageHandle, SystemTable);

    Print(L"PalisadeOS UEFI loader start\n");

    if (!BS || !RT) {
        Print(L"UEFI services unavailable\n");
        return EFI_ABORTED;
    }

    return EFI_SUCCESS;
}