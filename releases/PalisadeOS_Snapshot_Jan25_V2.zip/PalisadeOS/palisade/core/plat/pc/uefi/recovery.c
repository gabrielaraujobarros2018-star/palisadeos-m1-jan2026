#include <efi.h>
#include <efilib.h>

static UINT32 failure_count;

int should_fallback(void) {
    return failure_count >= 3;
}

void record_failure(void) {
    failure_count++;
}

CHAR16 *select_kernel(void) {
    if (should_fallback())
        return L"\\palisade\\kernel_fallback.efi";
    return L"\\palisade\\kernel.efi";
}