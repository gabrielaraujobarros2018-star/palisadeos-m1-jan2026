#include <efi.h>
#include <efilib.h>

void efi_debug(const CHAR16 *msg) {
    if (ST && ST->ConOut) {
        ST->ConOut->OutputString(ST->ConOut, msg);
        ST->ConOut->OutputString(ST->ConOut, L"\r\n");
    }
}