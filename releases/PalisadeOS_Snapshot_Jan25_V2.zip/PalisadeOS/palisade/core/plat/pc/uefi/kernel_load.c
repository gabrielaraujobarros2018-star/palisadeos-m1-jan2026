#include <efi.h>
#include <efilib.h>

EFI_STATUS load_kernel(
    EFI_HANDLE image,
    EFI_FILE_HANDLE root,
    CHAR16 *path,
    VOID **kernel,
    UINTN *kernel_size
) {
    EFI_FILE_HANDLE file;
    EFI_STATUS st = uefi_call_wrapper(
        root->Open, 5,
        root, &file, path, EFI_FILE_MODE_READ, 0
    );

    if (EFI_ERROR(st))
        return st;

    EFI_FILE_INFO *info;
    UINTN info_sz = SIZE_OF_EFI_FILE_INFO + 256;
    info = AllocatePool(info_sz);

    st = uefi_call_wrapper(
        file->GetInfo, 4,
        file, &GenericFileInfo, &info_sz, info
    );

    *kernel_size = info->FileSize;
    *kernel = AllocatePool(*kernel_size);

    st = uefi_call_wrapper(
        file->Read, 3,
        file, kernel_size, *kernel
    );

    return st;
}