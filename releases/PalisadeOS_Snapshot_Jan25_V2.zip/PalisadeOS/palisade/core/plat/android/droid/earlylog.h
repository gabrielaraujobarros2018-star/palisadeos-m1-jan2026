#pragma once

void earlylog(const char *msg);