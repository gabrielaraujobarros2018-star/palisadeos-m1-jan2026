# /misc

i named it "misc" because i didn't know where else to put it in. Part of directory tree shortening process ¯⁠\⁠_⁠༼⁠ ⁠ಥ⁠ ⁠‿⁠ ⁠ಥ⁠ ⁠༽⁠_⁠/⁠¯