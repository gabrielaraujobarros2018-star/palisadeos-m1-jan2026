#!/bin/sh
set -e

IMG=palisade.img

parted $IMG print
fdisk -l $IMG

OFFSET=$(parted $IMG unit B print | grep ESP | awk '{print $2}')
echo "ESP offset: $OFFSET"

test -s build/BOOTX64.EFI