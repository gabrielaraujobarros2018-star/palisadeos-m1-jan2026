#pragma once
void fs_mount_essential(void);
void fs_remount_rw(void);
void fs_remount_ro(void);