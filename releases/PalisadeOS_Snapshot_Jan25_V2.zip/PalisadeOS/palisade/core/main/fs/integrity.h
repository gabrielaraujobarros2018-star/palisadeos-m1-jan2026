#pragma once
#include "fs.h"
void fs_check_integrity(fs_type_t type);