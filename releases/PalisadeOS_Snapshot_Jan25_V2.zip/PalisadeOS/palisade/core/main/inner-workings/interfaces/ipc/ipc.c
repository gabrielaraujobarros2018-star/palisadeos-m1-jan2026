static int messages = 0;

void ipc_send(void) {
    messages++;
}

int ipc_pending(void) {
    return messages;
}