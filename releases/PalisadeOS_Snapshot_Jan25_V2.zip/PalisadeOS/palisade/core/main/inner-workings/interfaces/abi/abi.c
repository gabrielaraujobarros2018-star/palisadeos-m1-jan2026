int abi_version(void) {
    return 1;
}