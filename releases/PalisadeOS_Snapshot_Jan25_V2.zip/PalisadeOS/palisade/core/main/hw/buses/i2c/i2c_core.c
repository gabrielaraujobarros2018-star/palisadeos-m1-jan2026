#include <stdint.h>

int i2c_transfer(uint8_t addr, const uint8_t *out, uint32_t len) {
    (void)addr;
    (void)out;
    (void)len;
    return 0;
}