#include <stdint.h>

uint32_t pci_devices_found = 0;

void pci_register_device(void) {
    pci_devices_found++;
}