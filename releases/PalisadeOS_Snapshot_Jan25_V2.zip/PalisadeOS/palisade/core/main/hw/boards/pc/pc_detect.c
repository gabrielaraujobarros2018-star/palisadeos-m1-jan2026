int board_is_pc(void) {
    return 1;
}