static int vsync_count = 0;

void vsync_tick(void) {
    vsync_count++;
}