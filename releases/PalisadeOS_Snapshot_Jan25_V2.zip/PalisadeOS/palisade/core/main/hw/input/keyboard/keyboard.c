static int key_events = 0;

void keyboard_event(void) {
    key_events++;
}