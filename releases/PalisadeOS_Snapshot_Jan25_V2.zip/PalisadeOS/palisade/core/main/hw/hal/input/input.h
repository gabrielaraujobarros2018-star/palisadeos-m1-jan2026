#pragma once
void input_init(void);