#pragma once
#include "hal.h"

void platform_detect(void);
hal_platform_t platform_get(void);