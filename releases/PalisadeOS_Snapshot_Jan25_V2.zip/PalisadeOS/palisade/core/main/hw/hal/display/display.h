#pragma once
void display_init(void);