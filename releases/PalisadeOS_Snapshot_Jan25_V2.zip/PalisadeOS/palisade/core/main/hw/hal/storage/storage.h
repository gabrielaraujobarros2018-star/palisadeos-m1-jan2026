#pragma once
void storage_init(void);