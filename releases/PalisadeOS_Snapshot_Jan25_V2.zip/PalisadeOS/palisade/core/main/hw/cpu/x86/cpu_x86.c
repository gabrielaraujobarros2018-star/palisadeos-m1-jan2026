#include <stdint.h>

void cpu_x86_halt(void) {
    __asm__ volatile("hlt");
}