int bios_present(void) {
    return 1;
}