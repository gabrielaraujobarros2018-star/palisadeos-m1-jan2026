int uefi_present(void) {
    return 1;
}