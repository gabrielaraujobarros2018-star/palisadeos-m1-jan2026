int shell_run(void) {
    for (;;);
    return 0;
}