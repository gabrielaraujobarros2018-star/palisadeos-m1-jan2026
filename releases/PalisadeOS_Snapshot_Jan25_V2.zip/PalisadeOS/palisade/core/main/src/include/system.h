#pragma once
void kernel_panic(const char *);