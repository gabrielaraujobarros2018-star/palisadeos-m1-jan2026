extern void scheduler_add(void);

void system_schedule(void) {
    scheduler_add();
}