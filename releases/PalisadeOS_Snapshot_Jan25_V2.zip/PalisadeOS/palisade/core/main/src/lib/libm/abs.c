int abs(int v) {
    return v < 0 ? -v : v;
}