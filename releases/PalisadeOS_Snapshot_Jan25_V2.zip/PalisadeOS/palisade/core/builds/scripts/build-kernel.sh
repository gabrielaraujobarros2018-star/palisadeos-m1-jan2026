#!/bin/sh
set -e
. "$(dirname "$0")/../toolchain/env.sh"

ARCH="$1"
OUT="$PALISADE_ROOT/out/kernel/$ARCH"
mkdir -p "$OUT"

make -C kernel \
    ARCH="$ARCH" \
    O="$OUT" \
    LLVM=1 \
    KBUILD_BUILD_VERSION="$PALISADE_BUILD" \
    -j$(nproc)

echo "[KERNEL] Built for $ARCH"