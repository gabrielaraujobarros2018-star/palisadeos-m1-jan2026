#!/bin/sh
set -e
. "$(dirname "$0")/../toolchain/env.sh"

./build-kernel.sh x86_64
./build-kernel.sh arm64
./build-userland.sh

echo "[IMAGES] Artifacts ready"