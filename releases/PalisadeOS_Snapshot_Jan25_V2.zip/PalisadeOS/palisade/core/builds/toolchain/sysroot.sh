#!/bin/sh
set -e

SYSROOT="$PALISADE_ROOT/sysroots/$1"
mkdir -p "$SYSROOT"

rsync -a /usr/include "$SYSROOT/"
rsync -a /lib "$SYSROOT/"
rsync -a /lib64 "$SYSROOT/"

echo "[SYSROOT] Created sysroot for $1"