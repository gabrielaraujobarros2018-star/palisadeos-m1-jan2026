#!/bin/sh
set -e

PATCH_ROOT="/palisade/patch"
MANIFEST="$PATCH_ROOT/manifest/patch_manifest.conf"
LOCK="/run/patch.lock"

if [ -f "$LOCK" ]; then
    exit 0
fi

touch "$LOCK"
chmod 000 "$LOCK"

apply_patch() {
    src="$1"
    dst="$2"

    cp "$src" "$dst.tmp"
    sync
    mv "$dst.tmp" "$dst"
    sync
}

while read -r line; do
    case "$line" in
        \#*) continue ;;
        "") continue ;;
        *)
            SRC=$(echo "$line" | cut -d' ' -f1)
            DST=$(echo "$line" | cut -d' ' -f2)

            if [ -f "$SRC" ]; then
                apply_patch "$SRC" "$DST"
                chown root:root "$DST"
                chmod 755 "$DST"
            fi
        ;;
    esac
done < "$MANIFEST"

rm -f "$LOCK"
exit 0