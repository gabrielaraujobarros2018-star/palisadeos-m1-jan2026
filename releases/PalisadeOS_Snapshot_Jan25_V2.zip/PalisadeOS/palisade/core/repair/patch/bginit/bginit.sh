#!/bin/sh
set -e

PROC_BIN="/palisade/os/procManager/proc_manager"
BG_BIN="/palisade/patch/bginit/bg_worker"

if [ "$(id -u)" != "0" ]; then
    exit 1
fi

if ! pgrep -f proc_manager >/dev/null; then
    "$PROC_BIN" &
    sleep 1
fi

if ! pgrep -f bg_worker >/dev/null; then
    "$PROC_BIN" <<EOF &
spawn $BG_BIN IMMORTAL
EOF
fi

exit 0