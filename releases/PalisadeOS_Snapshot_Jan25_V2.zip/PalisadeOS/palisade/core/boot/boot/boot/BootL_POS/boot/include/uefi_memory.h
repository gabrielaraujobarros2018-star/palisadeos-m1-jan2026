#pragma once
#include <efi.h>

#ifdef __cplusplus
extern "C" {
#endif

extern EFI_MEMORY_DESCRIPTOR *mmap;
extern UINTN mmap_size;
extern UINTN map_key;
extern UINTN desc_size;
extern UINT32 desc_ver;

EFI_STATUS uefi_memmap(EFI_SYSTEM_TABLE *st);

/* Memory map must be retrieved
 * immediately before ExitBootServices.
 */

#ifdef __cplusplus
}
#endif