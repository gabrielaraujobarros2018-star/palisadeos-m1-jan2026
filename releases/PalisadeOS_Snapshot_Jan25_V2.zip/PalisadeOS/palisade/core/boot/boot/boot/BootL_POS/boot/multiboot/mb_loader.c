#include <stdint.h>
#include "boot.h"

void mb_load(uint32_t magic, uint32_t addr) {
    if (magic != 0x2BADB002) {
        boot_panic("Invalid multiboot magic");
    }
    boot_jump(*(uint32_t *)(addr + 28));
}