#include <stdint.h>

struct mem_region {
    uint64_t base;
    uint64_t length;
    uint32_t type;
};

static struct mem_region regions[32];
static int region_count = 0;

void mem_add(uint64_t base, uint64_t len, uint32_t type) {
    regions[region_count].base = base;
    regions[region_count].length = len;
    regions[region_count].type = type;
    region_count++;
}

int mem_count(void) {
    return region_count;
}

struct mem_region *mem_get(int i) {
    return &regions[i];
}