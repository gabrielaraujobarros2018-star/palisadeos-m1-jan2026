#include <efi.h>
#include <efilib.h>

EFI_STATUS efi_main(EFI_HANDLE img, EFI_SYSTEM_TABLE *st) {
    InitializeLib(img, st);
    Print(L"PalisadeOS Bootloader (UEFI)\n");
    uefi_memmap(st);
    Print(L"Memory map acquired\n");
    while (1) __asm__ __volatile__("hlt");
    return EFI_SUCCESS;
}