#include <efi.h>
#include <efilib.h>

EFI_GRAPHICS_OUTPUT_PROTOCOL *gop;

EFI_STATUS fb_init(EFI_SYSTEM_TABLE *st) {
    return uefi_call_wrapper(
        st->BootServices->LocateProtocol,
        3,
        &GraphicsOutputProtocol,
        NULL,
        (void**)&gop
    );
}