#include <stdint.h>

int kernel_verify(void *img, uint64_t size) {
    uint8_t *b = img;
    uint8_t acc = 0;
    for (uint64_t i = 0; i < size; i++)
        acc ^= b[i];
    return acc == 0;
}