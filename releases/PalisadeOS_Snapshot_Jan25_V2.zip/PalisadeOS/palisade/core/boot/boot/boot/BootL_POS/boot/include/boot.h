#pragma once
#include <stdint.h>

void boot_panic(const char *msg);
void boot_jump(uint64_t entry);

struct boot_info {
    uint64_t mem_map;
    uint32_t mem_entries;
};