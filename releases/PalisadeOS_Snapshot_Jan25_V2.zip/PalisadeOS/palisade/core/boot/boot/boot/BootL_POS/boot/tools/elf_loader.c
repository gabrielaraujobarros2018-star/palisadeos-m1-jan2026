#include <stdint.h>
#include <string.h>

struct elf64_hdr {
    unsigned char e_ident[16];
    uint16_t type;
    uint64_t entry;
};

uint64_t elf_load(void *image) {
    struct elf64_hdr *h = image;
    if (h->e_ident[0] != 0x7F) return 0;
    return h->entry;
}