#pragma once
#include <stdint.h>
#include <efi.h>

#ifdef __cplusplus
extern "C" {
#endif

EFI_STATUS fb_init(EFI_SYSTEM_TABLE *st);

/* After initialization:
 * - GOP pointer is guaranteed valid
 * - framebuffer mode is stable
 */

#ifdef __cplusplus
}
#endif