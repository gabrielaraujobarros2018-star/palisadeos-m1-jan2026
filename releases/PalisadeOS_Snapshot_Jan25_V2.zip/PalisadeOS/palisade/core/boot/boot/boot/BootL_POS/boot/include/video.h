#pragma once
#include <stdint.h>

void video_detect(void);
uint32_t video_width(void);
uint32_t video_height(void);
uint32_t video_bpp(void);