#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Loads an ELF image already present in memory.
 * Returns kernel entry address or 0 on failure.
 */
uint64_t elf_load(void *image);

/* ELF loader assumes:
 * - identity mapping
 * - validated image
 * - no dynamic relocation
 */

#ifdef __cplusplus
}
#endif