#include "version.h"

/*
 * Human-readable build identifier
 * Used for banners and diagnostics
 */
static const char build_stamp[] = PALISADE_BUILD_ID_STR;

const char *kernel_build_id(void)
{
    return build_stamp;
}