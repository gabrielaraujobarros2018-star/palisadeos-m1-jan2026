#pragma once

#include "types.h"

/* =========================================================
 * PalisadeOS / NeoKern versioning
 * ========================================================= */

#define PALISADE_KERNEL_MAJOR  1
#define PALISADE_KERNEL_MINOR  0
#define PALISADE_KERNEL_PATCH  3
#define PALISADE_BUILD_ID      20260118

/* Preprocessor stringification */
#define _STR(x) #x
#define STR(x)  _STR(x)

/* String form for banners / logs */
#define PALISADE_BUILD_ID_STR STR(PALISADE_BUILD_ID)

struct kernel_version {
    u32 major;
    u32 minor;
    u32 patch;
    u32 build;
};

const struct kernel_version *kernel_version_get(void);
int kernel_version_match(u32 major, u32 minor);