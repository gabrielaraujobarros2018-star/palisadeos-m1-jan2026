#ifndef NEOKERN_DEBUG_H
#define NEOKERN_DEBUG_H

#include "types.h"

void debug_banner(void);
void debug_checkpoint(const char *stage);

__attribute__((noreturn))
void debug_halt(void);

#endif