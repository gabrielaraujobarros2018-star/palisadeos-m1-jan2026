#ifndef KERNEL_ARCH_X64_PAGING64_H
#define KERNEL_ARCH_X64_PAGING64_H

void paging64_init(void);

#endif