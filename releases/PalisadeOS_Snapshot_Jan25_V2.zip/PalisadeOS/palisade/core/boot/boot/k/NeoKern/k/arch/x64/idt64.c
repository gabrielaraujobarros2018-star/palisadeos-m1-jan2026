#include <stdint.h>

struct idt_entry {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t  zero;
    uint8_t  type;
    uint16_t offset_high;
} __attribute__((packed));

static struct idt_entry idt[256];

void idt64_init(void) {
    for (int i = 0; i < 256; i++) {
        idt[i] = (struct idt_entry){0};
    }
}