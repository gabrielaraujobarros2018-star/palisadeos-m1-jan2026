#include <stdint.h>

int battery_percentage(void) {
    return 100;
}