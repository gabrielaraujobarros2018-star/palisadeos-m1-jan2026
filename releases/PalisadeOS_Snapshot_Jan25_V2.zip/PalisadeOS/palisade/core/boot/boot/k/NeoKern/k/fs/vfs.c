#include <stdint.h>

int vfs_mount(const char* fs) {
    if (!fs) return -1;
    return 0;
}