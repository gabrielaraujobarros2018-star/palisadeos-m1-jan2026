#ifndef KERNEL_DRIVERS_STORAGE_HDD_H
#define KERNEL_DRIVERS_STORAGE_HDD_H

int hdd_spinup(void);

#endif