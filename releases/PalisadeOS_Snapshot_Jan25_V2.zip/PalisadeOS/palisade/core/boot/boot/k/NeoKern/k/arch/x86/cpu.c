#include <stdint.h>

uint32_t cpu_get_flags(void) {
    uint32_t flags;
    __asm__ volatile (
        "pushf\n"
        "pop %0"
        : "=r"(flags)
    );
    return flags;
}