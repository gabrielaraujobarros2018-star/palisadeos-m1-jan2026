#include <stdint.h>
#include "kernel.h"

void x86_early_boot(void) {
    disable_interrupts();

    kernel_log("NeoKern x86_64 early boot");

    cpu_init();
    memory_init();

    kernel_main();

    for (;;) {
        asm volatile ("hlt");
    }
}

void disable_interrupts(void) {
    asm volatile ("cli");
}

void cpu_init(void) {
    kernel_log("x86 CPU init");
}

void memory_init(void) {
    kernel_log("x86 memory init");
}