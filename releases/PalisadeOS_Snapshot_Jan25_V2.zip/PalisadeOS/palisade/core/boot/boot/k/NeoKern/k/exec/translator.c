#include <stdint.h>

enum exec_format {
    EXEC_NATIVE,
    EXEC_TRANSLATED
};

static enum exec_format mode = EXEC_NATIVE;

void exec_set_translated(void) {
    mode = EXEC_TRANSLATED;
}

int exec_is_translated(void) {
    return mode == EXEC_TRANSLATED;
}