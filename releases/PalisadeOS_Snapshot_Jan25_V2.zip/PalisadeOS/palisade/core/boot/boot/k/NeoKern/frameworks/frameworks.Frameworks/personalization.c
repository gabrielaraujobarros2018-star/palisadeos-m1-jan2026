#include <stdint.h>

static uint32_t theme_id;
static uint32_t ui_flags;

void personalization_init(void) {
    theme_id = 0;
    ui_flags = 0;
}

void personalization_set_theme(uint32_t id) {
    theme_id = id;
}

uint32_t personalization_get_theme(void) {
    return theme_id;
}

/*
 * No assets loaded here.
 * Pure state holder.
 */