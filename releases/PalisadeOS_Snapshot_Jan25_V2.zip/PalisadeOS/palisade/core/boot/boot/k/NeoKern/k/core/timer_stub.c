
/*
 * NeoKern timer stub
 */

#include <kernel.h>

void timer_init(void) {
    /* no-op */
}

int timer_is_ready(void) {
    return 0;
}

u64 timer_ticks(void) {
    return 0;
}