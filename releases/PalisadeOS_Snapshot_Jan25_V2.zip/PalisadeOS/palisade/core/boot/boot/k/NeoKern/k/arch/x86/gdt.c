#include <stdint.h>

struct gdt_entry {
    uint16_t limit;
    uint16_t base;
    uint8_t  access;
    uint8_t  gran;
} __attribute__((packed));

static struct gdt_entry gdt[3];

void gdt_init(void) {
    gdt[0] = (struct gdt_entry){0};
}