#include <stdint.h>

int pipe_create(void) {
    return 0;
}