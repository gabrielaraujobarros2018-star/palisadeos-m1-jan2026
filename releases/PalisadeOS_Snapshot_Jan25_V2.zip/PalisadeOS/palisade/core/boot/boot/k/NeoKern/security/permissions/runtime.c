#include <stdint.h>

static int runtime_locked = 0;

void permission_runtime_init(void) {
    runtime_locked = 0;
}

void permission_runtime_lock(void) {
    runtime_locked = 1;
}

int permission_runtime_check(uint32_t perm) {
    if (runtime_locked)
        return 0;

    return perm != 0;
}

/*
 * Runtime permissions freeze after init.
 */