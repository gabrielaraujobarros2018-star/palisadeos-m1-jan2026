#ifndef KERNEL_ARCH_X86_GDT_H
#define KERNEL_ARCH_X86_GDT_H

void gdt_init(void);

#endif