/* ============================================================
 * NeoKern main.c
 * Translation unit anchor
 *
 * This file intentionally defines NO entry points.
 * It exists only to satisfy build systems that expect main.o.
 * ============================================================ */

#include <stdint.h>

/*
 * Do NOT define:
 *  - _start
 *  - kernel_start
 *  - kmain
 *  - kernel_main
 *
 * All real execution begins in:
 *   entry.S → kernel_start → kmain
 *
 * This file must remain symbol-empty.
 */

/* Optional dummy reference to avoid empty TU warnings */
__attribute__((used))
static const uint32_t neokern_main_unit = 0x4E4B4D41; /* "NKMA" */