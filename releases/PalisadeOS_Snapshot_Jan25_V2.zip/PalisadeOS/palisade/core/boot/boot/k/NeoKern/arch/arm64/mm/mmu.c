#include <kernel.h>

void arch_enable_mmu(void)
{
    /* Minimal MMU enable omitted for first boot */
    serial_write("MMU deferred\n");
}