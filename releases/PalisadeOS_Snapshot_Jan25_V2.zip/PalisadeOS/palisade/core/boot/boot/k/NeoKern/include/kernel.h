#ifndef NEOKERN_KERNEL_H
#define NEOKERN_KERNEL_H

#include "types.h"
#include "config.h"

/* =========================================================
 * Architecture selection
 * ========================================================= */
#if defined(__x86_64__)
    #define NEOKERN_ARCH_X86_64 1
#elif defined(__aarch64__)
    #define NEOKERN_ARCH_AARCH64 1
#else
    #error "Unsupported architecture"
#endif

/* =========================================================
 * Entry
 * ========================================================= */
/*
 * kernel_main():
 * - x86_64: entered after long mode + paging
 * - AArch64: entered from EL1/EL2 with MMU possibly off
 */
void kernel_main(void);

/* =========================================================
 * Panic
 * ========================================================= */
__attribute__((noreturn))
void panic(u64 code);

/* =========================================================
 * Debug
 * ========================================================= */
void debug_banner(void);
void debug_checkpoint(const char *stage);

__attribute__((noreturn))
static inline void debug_halt(void)
{
#if defined(NEOKERN_ARCH_X86_64)
    for (;;) {
        asm volatile ("cli; hlt");
    }
#elif defined(NEOKERN_ARCH_AARCH64)
    for (;;) {
        asm volatile ("wfe");
    }
#endif
}

/* =========================================================
 * Interrupts
 * ========================================================= */
void interrupts_enforce_off(void);
int  interrupts_are_disabled(void);

/* =========================================================
 * MMU
 * ========================================================= */
/*
 * Must verify:
 *  - x86_64: CR0.PG, CR4, EFER.LME/LMA
 *  - AArch64: SCTLR_EL1.M
 */
int mmu_validate_state(void);

/* =========================================================
 * Runtime
 * ========================================================= */
void runtime_init(void);

/* =========================================================
 * Heap
 * ========================================================= */
void *heap_alloc(u64 size);
u64   heap_used(void);

/* =========================================================
 * Timer
 * ========================================================= */
/*
 * x86_64: PIT / HPET / TSC
 * ARM64 : CNTVCT_EL0 / CNTFRQ_EL0
 */
void timer_init(void);
int  timer_is_ready(void);
u64  timer_ticks(void);

/* =========================================================
 * Serial
 * ========================================================= */
/*
 * x86_64: legacy COM1 or MMIO UART
 * ARM64 : PL011 / SoC UART (DT-provided)
 */
void serial_init(void);
void serial_write(const char *s);

/* =========================================================
 * Architecture helpers (inline, no ABI impact)
 * ========================================================= */
static inline void arch_disable_interrupts(void)
{
#if defined(NEOKERN_ARCH_X86_64)
    asm volatile ("cli" ::: "memory");
#elif defined(NEOKERN_ARCH_AARCH64)
    /* Mask IRQ + FIQ */
    asm volatile ("msr DAIFSet, #0xf" ::: "memory");
#endif
}

static inline int arch_interrupts_disabled(void)
{
#if defined(NEOKERN_ARCH_X86_64)
    u64 flags;
    asm volatile ("pushfq; pop %0" : "=r"(flags));
    return !(flags & (1ULL << 9));
#elif defined(NEOKERN_ARCH_AARCH64)
    u64 daif;
    asm volatile ("mrs %0, DAIF" : "=r"(daif));
    return (daif & (1ULL << 7)) != 0;
#endif
}

#endif /* NEOKERN_KERNEL_H */