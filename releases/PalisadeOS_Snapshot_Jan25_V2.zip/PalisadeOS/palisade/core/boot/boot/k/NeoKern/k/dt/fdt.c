#include <types.h>
#include <kernel.h>

#define FDT_MAGIC 0xd00dfeed

struct fdt_header {
    u32 magic;
};

int fdt_validate(void *dtb)
{
    struct fdt_header *h = (struct fdt_header *)dtb;
    return h->magic == __builtin_bswap32(FDT_MAGIC);
}