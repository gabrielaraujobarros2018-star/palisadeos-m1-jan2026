#include <stdint.h>

static uint32_t current_task = 0;

uint32_t sched_current(void) {
    return current_task;
}

void sched_next(void) {
    current_task++;
}