#include <stdint.h>

extern void serial_write(const char *s);

__attribute__((noreturn))
void panic(uint64_t code) {
    serial_write("\n[KERNEL PANIC] CODE=");
    serial_write("0x");

    char hex[] = "0123456789ABCDEF";
    char out[3];
    out[0] = hex[(code >> 4) & 0xF];
    out[1] = hex[code & 0xF];
    out[2] = 0;

    serial_write(out);
    serial_write("\nSystem halted.\n");

    while (1) {
        __asm__ volatile ("cli; hlt");
    }
}