#ifndef KERNEL_IPC_PIPE_H
#define KERNEL_IPC_PIPE_H

int pipe_create(void);

#endif