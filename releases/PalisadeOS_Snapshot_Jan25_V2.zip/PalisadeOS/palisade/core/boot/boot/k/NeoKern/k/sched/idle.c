void cpu_idle(void) {
    for (;;) {
        __asm__ volatile ("hlt");
    }
}