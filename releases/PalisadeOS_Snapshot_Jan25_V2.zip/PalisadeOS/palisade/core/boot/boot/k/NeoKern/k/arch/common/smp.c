#include <stdint.h>

static uint8_t cpu_count = 1;

uint8_t smp_cpu_count(void) {
    return cpu_count;
}