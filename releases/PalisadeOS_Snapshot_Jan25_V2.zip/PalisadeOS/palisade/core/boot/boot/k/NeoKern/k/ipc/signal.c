#include <stdint.h>

void signal_raise(int sig) {
    (void)sig;
}