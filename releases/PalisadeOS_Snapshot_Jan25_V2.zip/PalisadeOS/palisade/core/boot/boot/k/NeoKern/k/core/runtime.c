/*
 * NeoKern runtime initialization
 */

#include <kernel.h>

void runtime_init(void) {
    serial_init();
    timer_init();
}