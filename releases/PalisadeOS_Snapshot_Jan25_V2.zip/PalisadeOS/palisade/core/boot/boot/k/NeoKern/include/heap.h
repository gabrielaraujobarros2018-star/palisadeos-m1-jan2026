#ifndef NEOKERN_HEAP_H
#define NEOKERN_HEAP_H

#include "types.h"

void *heap_alloc(u64 size);
u64   heap_used(void);

#endif