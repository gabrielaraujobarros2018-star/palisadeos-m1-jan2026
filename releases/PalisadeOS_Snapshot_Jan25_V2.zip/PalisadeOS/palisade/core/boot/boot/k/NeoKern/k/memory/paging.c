#include "kernel.h"

/*
 * Paging is assumed to be enabled by the bootloader.
 * We only validate, never modify, at this stage.
 */
int mmu_validate_state(void) {
#if defined(NEOKERN_ARCH_X86_64)
    u64 cr0;
    __asm__ volatile ("mov %%cr0, %0" : "=r"(cr0));
    return (cr0 & (1ULL << 31)) != 0; /* PG bit */
#elif defined(NEOKERN_ARCH_AARCH64)
    u64 sctlr;
    __asm__ volatile ("mrs %0, SCTLR_EL1" : "=r"(sctlr));
    return (sctlr & 1) != 0;
#endif
}