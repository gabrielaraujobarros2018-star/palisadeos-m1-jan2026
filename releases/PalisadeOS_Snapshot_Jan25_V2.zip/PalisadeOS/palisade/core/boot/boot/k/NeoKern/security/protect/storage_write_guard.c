/* NeoKern/security/protect/storage_write_guard.c */
#include <stdint.h>

static int writes_allowed = 1;

void storage_write_guard_init(void) {
    writes_allowed = 1;
}

void storage_write_guard_block(void) {
    writes_allowed = 0;
}

int storage_write_allowed(void) {
    return writes_allowed;
}

void storage_write_guard_check(void) {
    if (!writes_allowed) {
        /* Block IO path upstream */
    }
}

/*
 * Used when:
 * - FS corruption detected
 * - Power instability detected
 */