#include <stdint.h>

#define PERM_MAX 16

static uint32_t policy_table[PERM_MAX];

void permission_policy_init(void) {
    for (int i = 0; i < PERM_MAX; i++)
        policy_table[i] = 0;
}

void permission_policy_set(uint32_t id, uint32_t mask) {
    if (id < PERM_MAX)
        policy_table[id] = mask;
}

uint32_t permission_policy_get(uint32_t id) {
    if (id >= PERM_MAX)
        return 0;

    return policy_table[id];
}