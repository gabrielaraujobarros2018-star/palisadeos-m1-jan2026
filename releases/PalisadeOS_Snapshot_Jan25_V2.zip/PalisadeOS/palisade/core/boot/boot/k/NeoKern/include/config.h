#pragma once

/*
 * NeoKern build configuration
 * Architecture-independent policy
 */

/* =========================================================
 * Kernel identity
 * ========================================================= */

#define KERNEL_STACK_SIZE   16384
#define KERNEL_NAME         "NeoKern"
#define KERNEL_VERSION      "0.1"

/* =========================================================
 * Feature toggles
 * ========================================================= */

#define ENABLE_EARLY_LOG    1
#define ENABLE_PANIC_HALT   1

#if ENABLE_EARLY_LOG
    /* Implemented by serial / debug subsystem */
    void kernel_log(const char *msg);
    #define EARLY_LOG(msg) kernel_log(msg)
#else
    #define EARLY_LOG(msg) do {} while (0)
#endif

/* =========================================================
 * Kernel panic codes
 * ========================================================= */

#define PANIC_MMU_DISABLED   0x00000001
#define PANIC_KERNEL_RETURN  0x00000002
#define PANIC_BAD_DTB        0x00000003
#define PANIC_ARCH_FAILURE  0x00000004
