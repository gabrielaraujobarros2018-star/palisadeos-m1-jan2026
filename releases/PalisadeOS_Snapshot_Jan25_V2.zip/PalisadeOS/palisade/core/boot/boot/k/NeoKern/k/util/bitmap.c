#include <stdint.h>

int bitmap_test(uint8_t* map, uint32_t bit) {
    return map[bit / 8] & (1 << (bit % 8));
}

void bitmap_set(uint8_t* map, uint32_t bit) {
    map[bit / 8] |= (1 << (bit % 8));
}