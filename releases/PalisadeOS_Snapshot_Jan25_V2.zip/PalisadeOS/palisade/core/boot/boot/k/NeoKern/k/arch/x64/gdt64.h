#ifndef KERNEL_ARCH_X64_GDT64_H
#define KERNEL_ARCH_X64_GDT64_H

void gdt64_init(void);

#endif