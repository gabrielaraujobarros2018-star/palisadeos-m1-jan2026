#ifndef KERNEL_DRIVERS_POWER_LI_ION_H
#define KERNEL_DRIVERS_POWER_LI_ION_H

int battery_percentage(void);

#endif