#ifndef KERNEL_UTIL_LOG_H
#define KERNEL_UTIL_LOG_H

void kernel_log(const char* msg);

#endif