#include <stdint.h>

int ata_detect(void) {
    return 0;
}