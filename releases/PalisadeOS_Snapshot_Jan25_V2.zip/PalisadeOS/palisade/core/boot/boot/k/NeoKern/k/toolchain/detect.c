int kernel_compiler_is_clang(void) {
#ifdef __clang__
    return 1;
#else
    return 0;
#endif
}

int kernel_compiler_is_gcc(void) {
#ifdef __GNUC__
    return 1;
#else
    return 0;
#endif
}