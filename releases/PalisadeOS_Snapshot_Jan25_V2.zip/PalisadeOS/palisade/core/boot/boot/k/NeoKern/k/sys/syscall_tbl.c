#include <stdint.h>

extern uint64_t sys_null(void);

uint64_t (*syscall_table[])(void) = {
    sys_null
};