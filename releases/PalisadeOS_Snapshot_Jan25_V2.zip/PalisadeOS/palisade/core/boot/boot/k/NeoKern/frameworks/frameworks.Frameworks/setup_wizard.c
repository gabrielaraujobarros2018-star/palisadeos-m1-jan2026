#include <stdint.h>

static int wizard_enabled = 0;
static int wizard_completed = 0;

void setup_wizard_enable(void) {
    wizard_enabled = 1;
}

int setup_wizard_should_run(void) {
    return wizard_enabled && !wizard_completed;
}

void setup_wizard_complete(void) {
    wizard_completed = 1;
}

/*
 * Wizard only runs if:
 * - Enabled via boot options
 * - Or enabled in recovery
 */