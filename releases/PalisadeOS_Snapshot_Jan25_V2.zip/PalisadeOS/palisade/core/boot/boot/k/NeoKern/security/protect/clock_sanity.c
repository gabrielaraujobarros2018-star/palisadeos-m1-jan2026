/* NeoKern/security/protect/clock_sanity.c */
#include <stdint.h>

static uint64_t last_time = 0;

void clock_sanity_init(uint64_t now) {
    last_time = now;
}

int clock_sanity_check(uint64_t now) {
    if (now < last_time) {
        return 0; /* rollback detected */
    }

    if ((now - last_time) > (60ULL * 60ULL * 24ULL * 365ULL)) {
        return 0; /* absurd jump */
    }

    last_time = now;
    return 1;
}

/*
 * Protects:
 * - Filesystems
 * - Crypto
 * - Update logic
 */