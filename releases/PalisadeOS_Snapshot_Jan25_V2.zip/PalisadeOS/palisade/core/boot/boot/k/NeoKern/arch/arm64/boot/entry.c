#include <types.h>
#include <kernel.h>

extern void kernel_start(void *dtb);

void arm64_entry(void *dtb)
{
    kernel_start(dtb);
    for (;;)
        __asm__ volatile("wfe");
}