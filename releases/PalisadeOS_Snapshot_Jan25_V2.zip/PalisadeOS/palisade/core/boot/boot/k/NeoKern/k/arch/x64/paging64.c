#include <stdint.h>

static uint64_t pml4[512] __attribute__((aligned(4096)));

void paging64_init(void) {
    pml4[0] = 0x0000000000000003;
}