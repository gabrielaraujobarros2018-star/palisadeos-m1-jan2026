#ifndef NEOKERN_RUNTIME_H
#define NEOKERN_RUNTIME_H

#include "types.h"

void runtime_init(void);

#endif