#ifndef KERNEL_ARCH_X64_IDT64_H
#define KERNEL_ARCH_X64_IDT64_H

void idt64_init(void);

#endif