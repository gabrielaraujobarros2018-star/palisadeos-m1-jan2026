#ifndef KERNEL_ARCH_X86_CPU_H
#define KERNEL_ARCH_X86_CPU_H

#include <stdint.h>

uint32_t cpu_get_flags(void);

#endif