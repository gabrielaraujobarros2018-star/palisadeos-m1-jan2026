#include <stdint.h>

struct idt_entry {
    uint16_t offset;
    uint16_t selector;
    uint8_t  zero;
    uint8_t  flags;
} __attribute__((packed));

static struct idt_entry idt[256];

void idt_init(void) {
    for (int i = 0; i < 256; i++) {
        idt[i] = (struct idt_entry){0};
    }
}