#include <stdint.h>

static volatile uint16_t* vga = (uint16_t*)0xB8000;
static uint8_t cursor = 0;

void kernel_log(const char* msg) {
    while (*msg) {
        vga[cursor++] = (0x07 << 8) | *msg++;
        if (cursor >= 80) cursor = 0;
    }
}