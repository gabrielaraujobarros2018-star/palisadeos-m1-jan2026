#pragma once

#include "types.h"

/*
 * x86_64 architecture interface
 * No ARM symbols allowed here
 */

void x86_early_boot(void);

void disable_interrupts(void);
void cpu_init(void);
void memory_init(void);

/* Control registers helpers */
static inline u64 read_cr0(void) {
    u64 val;
    asm volatile ("mov %%cr0, %0" : "=r"(val));
    return val;
}

static inline void write_cr0(u64 val) {
    asm volatile ("mov %0, %%cr0" :: "r"(val));
}

/* Halt CPU safely */
static inline void x86_halt(void) {
    asm volatile ("hlt");
}