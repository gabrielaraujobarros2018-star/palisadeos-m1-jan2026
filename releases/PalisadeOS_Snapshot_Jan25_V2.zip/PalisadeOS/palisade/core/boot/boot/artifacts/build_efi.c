#include "../include/boot.h"

const char *efi_artifact_name(void) {
    return "PalisadeOS-b01172026-x86_64.efi";
}

void efi_artifact_describe(void) {
    boot_log("EFI ARTIFACT");
    boot_log(efi_artifact_name());
    boot_log("UEFI ONLY");
}