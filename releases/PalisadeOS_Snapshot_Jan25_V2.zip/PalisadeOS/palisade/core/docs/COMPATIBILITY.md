# PalisadeOS Compatibility

**Starting from build:** `b01202026`  
This document defines the **actual, tested, and architecturally supported compatibility surface** of PalisadeOS.  
Compatibility is based on **real boot paths and enforced contracts**, not theoretical portability.

---

## Supported CPU Architectures

### Fully Supported
- **x86_64**
- **ARM64 (AArch64)**

Both architectures:
- Share the **same kernel entry ABI**
- Follow the **same init path after early arch bring-up**
- Use the **same panic and failure handling paths**
- Have **no architecture-specific assumptions in kernel core**

---

## Supported Firmware Environments

### Legacy BIOS (x86_64)
**Status:** Fully supported

- MBR-safe bootloader
- No GPT assumptions
- Correct A20 handling
- 16-bit → 32-bit → 64-bit transition
- BIOS interrupts confined to real mode only
- E820 memory map parsing
- Identity mapping until long mode
- Mandatory serial debug output
- Fallback bootloader support

**Boot methods:**
- Direct disk boot (MBR)
- Chainloading from existing BIOS bootloaders

---

### UEFI (x86_64 + ARM64)
**Status:** Fully supported

- Full UEFI Boot Services consumption
- Clean `ExitBootServices`
- EFI memory map validation
- Runtime services mapping awareness
- Direct EFI boot (`.efi` binary)
- GRUB chainloading support
- FAT32 ESP filesystem support
- GPT-safe disk enumeration
- No disk order assumptions
- Initrd and kernel command line handling
- Serial and framebuffer debug output
- Bootable EFI recovery image
- Fallback kernel selection logic

**UEFI modes:**
- UEFI-only
- UEFI with CSM disabled
- Secure Boot: *not supported yet*

---

### Android Bootloader Environment (ARM64)
**Status:** Conditionally supported (device-dependent)

- Android `boot.img` v3 / v4 parsing
- Unlocked bootloader required
- Kernel, ramdisk, and cmdline offsets validated
- No Android userspace or `init` dependency
- Vendor DTB / DTBO accepted without modification
- Read-only probing of block devices by default
- A/B slot detection
- Dynamic partition detection
- Vendor, modem, persist, and metadata partitions are never touched
- Fastboot-compatible recovery strategy
- Boot failure counter with rollback logic

**Limitations:**
- SoC-specific MMIO, clocks, regulators, and display pipelines may be required
- Not all Android devices are supported yet
- Compatibility improves per-device, not globally

---

## Storage Compatibility

### Supported
- SATA (via BIOS / UEFI)
- NVMe (via UEFI)
- eMMC / UFS (Android devices, read-only by default)
- GPT (UEFI, Android)
- MBR (Legacy BIOS)

### Safety Rules
- Unknown storage layouts are mounted **read-only**
- No automatic writes without explicit allowlisting
- Installation is refused if no recovery path is present

---

## Memory & Boot Safety Guarantees

- Firmware ambiguity → **boot abort**
- Inconsistent memory map → **boot abort**
- Missing or invalid DTB on ARM64 → **boot abort**
- Reserved memory regions are protected
- Kernel never overwrites firmware-owned memory
- Recovery path is mandatory for installation

---

## Display & Input

### Supported (varies by platform)
- Framebuffer console (early and fallback)
- DRM / GOP framebuffer (UEFI)
- Touchscreen input (Android devices, device-dependent)
- Keyboard input (PC platforms)

### Guaranteed
- No-GUI fallback is always available
- Serial console is always available on supported platforms

---

## Recovery Compatibility

### Supported Recovery Paths
- Legacy BIOS fallback bootloader
- UEFI EFI recovery image
- Android fastboot-compatible recovery
- Alternate kernel selection on repeated boot failure

### Enforcement
- If recovery is unavailable, installation is refused
- Boot may proceed, installation may not

---

## Not Supported (as of b01202026)

- Secure Boot (UEFI)
- ARM32 (AArch32)
- PowerPC, RISC-V, MIPS
- Locked Android bootloaders
- Vendor-modified Android boot flows without standard `boot.img`
- Automatic vendor firmware flashing

---

## Compatibility Philosophy

PalisadeOS prioritizes:
- **Correctness over convenience**
- **Safety over silent failure**
- **Explicit contracts over platform hacks**

Compatibility is added only when it can be enforced without compromising these principles.

---

**This document is authoritative for build `b01202026` and later unless explicitly superseded.**