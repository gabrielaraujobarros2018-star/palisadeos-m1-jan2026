# PalisadeOS Memory Map (Authoritative)

This file is the only valid description of memory ownership.

## Regions

- Firmware Reserved
- Kernel Image
- Kernel Stack
- Early Heap
- MMIO

Structure is identical across platforms.
Only addresses differ.