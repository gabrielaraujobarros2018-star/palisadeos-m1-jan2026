# PalisadeOS Boot Contract (b01162026-SP1)

This document defines the immutable bootloader → kernel ABI.

## Entry Conditions

### CPU State
- CPU is in:
  - x86_64: Long Mode, paging enabled
  - ARM64: EL1, MMU enabled
- Interrupts: DISABLED
- One core only (BSP)

### Stack
- Stack pointer is valid
- Stack is writable
- Stack size ≥ 16 KiB
- Stack is NOT shared with firmware

### Registers

#### x86_64
- RDI: pointer to boot_info
- RSI–R15: undefined
- RSP: valid stack
- CR3: kernel page tables

#### ARM64
- X0: pointer to boot_info
- X1–X30: undefined
- SP: valid stack
- TTBR1_EL1: kernel tables

### Memory Guarantees
- Kernel image is fully mapped and executable
- boot_info structure is readable
- Firmware regions are NOT touched

## Prohibitions
- Kernel must NOT return to bootloader
- Kernel must NOT assume identity mapping
- Kernel must NOT enable interrupts before init