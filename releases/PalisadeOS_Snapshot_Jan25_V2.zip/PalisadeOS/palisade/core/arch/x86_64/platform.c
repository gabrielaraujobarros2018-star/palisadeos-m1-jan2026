#include <stdint.h>

void platform_init_x86_64(void) {
    /* explicit, static, predictable */
}