#include <stdint.h>

void platform_init_arm64(void) {
    /* explicit, static, predictable */
}