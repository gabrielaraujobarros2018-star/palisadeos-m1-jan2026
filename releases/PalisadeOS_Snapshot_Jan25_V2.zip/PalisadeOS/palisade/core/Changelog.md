# Palisade

## Palisade 1.0.1 - Rebranding

NeoProto -> Palisade

Plus, added slogan:

> Palisade OS — a traditional operating system built around strict boundaries and layered control.

## Palisade 1.0.2 - Compiling of Some files

- Compiled: AuraWords.img
- Compiled: AuraWordsShortcut
- Compiled: AppManager
- Updated: Manifests

SOURCE LANGUAGE   SOURCE FILE(S)           OUTPUT BINARY
--------------------------------------------------------
C++               10 files                 AuraWords.img
Rust              1 file                   AuraWordsShortcut
Rust              1 file                   AppManager

## Palisade 1.0.2 - Sequel

- Compiled: GroundzeroStore
- Optional: Hook Points (600 files), Hash Indexes (600 files)
- Bootloader Directory tree finished